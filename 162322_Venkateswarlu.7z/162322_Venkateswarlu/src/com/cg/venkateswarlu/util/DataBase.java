package com.cg.venkateswarlu.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.venkateswarlu.bean.TransportBean;

public class DataBase {
	private static Map<String,String> transportDetails=new HashMap<>();
	private static Map<Integer,TransportBean> booktransport=new HashMap<>();
		public static Map<String, String> getTransportDetails() {
			transportDetails.put("F-1","Flight");
			transportDetails.put("T-2","Train");
			transportDetails.put("Ta-1","Taxi");
				
			return transportDetails;
		}

		public static void addTransport(TransportBean bean) {
			booktransport.put(bean.getId(),bean);
			
		}

}
