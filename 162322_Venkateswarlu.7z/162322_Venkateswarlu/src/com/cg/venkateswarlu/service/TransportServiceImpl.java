package com.cg.venkateswarlu.service;

import java.util.Map;

import com.cg.venkateswarlu.bean.TransportBean;
import com.cg.venkateswarlu.dao.ITransportDao;
import com.cg.venkateswarlu.dao.TransportDavoImpl;

public class TransportServiceImpl implements ITransportService {

	ITransportDao dao=new TransportDavoImpl();
	
	@Override
	public Map<String, String> getTransportDetails() {
		// TODO Auto-generated method stub
		return dao.getTransportDetails();
	}

	@Override
	public void addTransport(TransportBean bean) {
		// TODO Auto-generated method stub
		dao.addTransport(bean);
	}
	
	
}
