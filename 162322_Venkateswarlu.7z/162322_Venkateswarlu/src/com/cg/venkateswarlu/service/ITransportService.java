package com.cg.venkateswarlu.service;

import java.util.Map;

import com.cg.venkateswarlu.bean.TransportBean;

public interface ITransportService {

	Map<String, String> getTransportDetails();

	void addTransport(TransportBean bean);
	
}
