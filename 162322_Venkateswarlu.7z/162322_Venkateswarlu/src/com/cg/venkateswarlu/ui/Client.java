package com.cg.venkateswarlu.ui;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.Scanner;

import com.cg.venkateswarlu.bean.TransportBean;
import com.cg.venkateswarlu.service.ITransportService;
import com.cg.venkateswarlu.service.TransportServiceImpl;

public class Client {
	
	public static void main(String[] args) {
		TransportBean bean = new TransportBean();
		ITransportService service = new TransportServiceImpl();
		Map<String, String> transportDetails = service.getTransportDetails();
		System.out.println("Mode of Transport");
		int count = 1;
		for (Map.Entry<String, String> entrySet : transportDetails.entrySet()) {
			System.out.println(count + " . " + entrySet.getValue());
			count++;
		}
		System.out.println("enter option");
		Scanner scanner = new Scanner(System.in);
		int choice = scanner.nextInt();
		int count1 = 1;
		for (Map.Entry<String, String> entrySet : transportDetails.entrySet()) {
			if (choice == count1) {
				bean.setTransportCategoryId(entrySet.getKey());

			}
			count1++;
		}

		int id = (int) (Math.random() * 10000);
		bean.setId(id);
		System.out.println("Enter reason");
		scanner.nextLine();
		String reason = scanner.nextLine();
		bean.setReason(reason);
		System.out.println("when 1.This week");
		System.out.println("     2.Next week");
		System.out.println("     3.Next Month");
		System.out.println(" ");
		int whenChoice = scanner.nextInt();
		if (whenChoice == 1) {
			bean.setWhen("1.This week");
		}
		if (whenChoice == 2) {
			bean.setWhen("2.Next week");
		}
		if (whenChoice == 3) {
			bean.setWhen("3.Next Month");
		}
		service.addTransport(bean);
		LocalDateTime ldt = LocalDateTime.now();
		DateTimeFormatter f = DateTimeFormatter
				.ofPattern("dd MMMM yyyy   hh:mm  a");
		System.out.println("Booked with "+  id  +  " on "   + ldt.format(f));
	}


}
