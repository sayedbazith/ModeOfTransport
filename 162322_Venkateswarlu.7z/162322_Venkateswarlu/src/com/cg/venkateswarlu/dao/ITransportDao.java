package com.cg.venkateswarlu.dao;

import java.util.Map;

import com.cg.venkateswarlu.bean.TransportBean;

public interface ITransportDao {
	
	Map<String, String> getTransportDetails();

	void addTransport(TransportBean bean);


}
