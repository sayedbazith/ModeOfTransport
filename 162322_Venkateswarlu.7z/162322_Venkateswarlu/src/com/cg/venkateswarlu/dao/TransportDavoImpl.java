package com.cg.venkateswarlu.dao;

import java.util.Map;

import com.cg.venkateswarlu.bean.TransportBean;
import com.cg.venkateswarlu.util.DataBase;

public class TransportDavoImpl implements ITransportDao {

	
	@Override
	public Map<String, String> getTransportDetails() {
		// TODO Auto-generated method stub
		return DataBase.getTransportDetails();
	}

	@Override
	public void addTransport(TransportBean bean) {
		DataBase.addTransport(bean);
		
	}
}
