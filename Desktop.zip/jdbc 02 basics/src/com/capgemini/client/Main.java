package com.capgemini.client;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Main 
{
	public static Connection createConnection() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		String dbURL="jdbc:mysql://localhost:3306/demodb";

		String userName="root";
		String password="pass";
		Connection connection=DriverManager.getConnection(dbURL, userName, password);
		
		return connection;
	}
	
	public static void insertRecord() throws ClassNotFoundException, SQLException
	{
		Connection connection=createConnection();
		String SQL1="insert into customer values(100,'kiran traders','chennai',6000.00)";
		String SQL2="insert into customer values(20,'kiran traders','chennai',6000.00)";
		String SQL3="insert into customer values(30,'kiran traders','chennai',6000.00)";
		String SQL4="insert into customer values(40,'kiran traders','chennai',6000.00)";
		String SQL5="insert into customer values(50,'kiran traders','chennai',6000.00)";
		Statement statement =connection.createStatement();
		int r=statement.executeUpdate(SQL1);
		int r2=statement.executeUpdate(SQL2);
		int r3=statement.executeUpdate(SQL3);
		int r4=statement.executeUpdate(SQL4);
		int r5=statement.executeUpdate(SQL5);
		System.out.println(connection);
		statement.close();
		connection.close();
	}
	
	
	public static void updateRecord() throws ClassNotFoundException, SQLException
	{
		Connection connection=createConnection();
		String SQL1="update customer set C_amt=C_amt+1000 where C_id=100";
		
		Statement statement =connection.createStatement();
		int r=statement.executeUpdate(SQL1);
		
		System.out.println("row updated");
		statement.close();
	}
	
	public static void deleteRecord() throws ClassNotFoundException, SQLException
	{
		Connection connection=createConnection();
		String SQL1="delete from customer where C_id=100";
		
		Statement statement =connection.createStatement();
		int r=statement.executeUpdate(SQL1);
		
		System.out.println("row deleted");
		statement.close();
		connection.close();
	}
	
	public static void displayAll() throws ClassNotFoundException, SQLException
	{
		Connection connection=createConnection();
		String SQL1="select * from customer";
		
		Statement statement =connection.createStatement();
		ResultSet rs=statement.executeQuery(SQL1);
		while(rs.next()){
		System.out.println(rs.getInt(1) +" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getDouble(4));
		}
		rs.close();
		//System.out.println("row fetched");
		statement.close();
		connection.close();
	}
	
	public static void displayOneRecord(int id) throws ClassNotFoundException, SQLException
	{
		Connection connection=createConnection();
		String SQL1="select * from customer where C_id="+id;
		
		Statement statement =connection.createStatement();
		ResultSet r=statement.executeQuery(SQL1);
		r.next();
		System.out.println(r.getInt(1) +" "+r.getString(2)+" "+r.getString(3)+" "+r.getDouble(4));
		//System.out.println("row fetched");
		statement.close();
		connection.close();
	}
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException              
	{
		
		displayOneRecord(50);
		
	}
}
