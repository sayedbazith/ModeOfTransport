package com.capgemini.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.bussiness.Customer;

public class CustomerDAOImp implements CustomerDAO {

	@Override
	public boolean addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean removeCustomer(int customerId) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection connection=null;
		connection=ConnectionManager.createConnection();
		String sql="delete from customer where C_id=?";
		PreparedStatement statement=connection.prepareStatement(sql);
		statement.setInt(1, customerId);
		statement.execute();
		statement.close();
		ConnectionManager.closeConnection(connection);
		return true;
	}

	@Override
	public boolean updateCustomer(Customer customer) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection connection=ConnectionManager.createConnection();
		String sql="update from customer where id=?";
		return false;
	}

	@Override
	public Customer findCustomer(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customer> getAll() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		List<Customer> list=new ArrayList<Customer>();
		Connection connection=null;
		connection=ConnectionManager.createConnection();
		String sql="select * from customer";
		PreparedStatement statement=connection.prepareStatement(sql);
		ResultSet rs=statement.executeQuery();
		while(rs.next())
		{
			Customer bean=new Customer();
			bean.setId(rs.getInt(1));
			bean.setName(rs.getString(2));
			bean.setCity(rs.getString(3));
			bean.setOutStandingBalance(rs.getDouble(4));
			list.add(bean);
		}
		statement.close();
		ConnectionManager.closeConnection(connection);
		return list;
	}

}
