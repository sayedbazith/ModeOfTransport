package com.capgemini.ui;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.bussiness.Customer;
import com.capgemini.db.CustomerDAO;
import com.capgemini.db.CustomerDAOImp;

public class Main {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		System.out.println("customer application");
		System.out
				.println("---------------------------------------------------------");
		System.out.println("1) add new customer");
		System.out.println("2) update customer");
		System.out.println("3) display all customer");
		System.out.println("4) delete customer");
		System.out.println("5) exit");
		Scanner scan = new Scanner(System.in);
		System.out.println("enter the option ");
		int choice = scan.nextInt();
		switch (choice) 
		{
			case 1:
				add();
				break;
			case 2:
				update();
				break;
			case 3:
				display();
				break;
			case 4:
				remove();
				break;
			case 5:
				System.out.println("thank you!!!!!!!!!!!!!");
				System.exit(0);
				break;
			default:
				System.out.println("entered wrong option!");
				break;
		}
		scan.close();
	}
	public static void add()
	{
		
	}

	public static void update()
	{
		
	}
	public static void display() throws ClassNotFoundException, SQLException
	{
		CustomerDAO customerDao=new CustomerDAOImp();
		List<Customer> list=customerDao.getAll();
		for (Customer customer : list) 
		{
			System.out.println(customer);
		}
	}
	public static void remove() throws ClassNotFoundException, SQLException
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the id");
		int id=scan.nextInt();
		scan.close();
		CustomerDAO customerDao=new CustomerDAOImp();
		boolean result=customerDao.removeCustomer(id);
		if(result)
			System.out.println("successfully deleted");
		else
			System.out.println("not deleted");
	}
	
}
